"""Version of PodmanPy."""

__version__ = "5.0.0"
__compatible_version__ = "1.40"
